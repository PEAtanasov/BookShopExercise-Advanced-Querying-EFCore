﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => @"Server=DESKTOP-8NR9GDQ\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
