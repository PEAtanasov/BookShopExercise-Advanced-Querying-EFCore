﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            DbInitializer.ResetDatabase(db);
            string command = Console.ReadLine();
            Console.WriteLine(GetBooksByAgeRestriction(db,command));

        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var books = context.Books
                .ToArray()
                .Where(b => (b.AgeRestriction.ToString().ToLower()) == command.ToLower())
                .Select(b => b.Title)
                .ToArray();

            StringBuilder sb = new StringBuilder();
            foreach (var book in books.OrderBy(b=>b))
            {
                sb.AppendLine(book);
            }
            return sb.ToString().TrimEnd();
        }
    }
}


